#!/usr/bin/python

import os.path
import sys
import shutil
import ConfigParser
import re

from configTomcat import *

configFileBak = "connector.conf.bak"
configFile = "connector.conf"

fedoraParameters = ["host", "port", "user", "password", "protocol", "context", "phrase", "rest", "gsearchcontext", "gsearchfields"]
xtfParameters = ["host", "port"]

def exitWithMessage(message):
    print message
    exit()


def readConfig():
    config = ConfigParser.RawConfigParser()
    config.read(configFile)
    list = []
    for section in config.sections():
        map = {"name": section}
    
        if not config.has_option(section, "type"):
            exitWithMessage("Please specify type for the workspace %s!" % section)
    
        type = config.get(section, "type")
        map["type"] = type

        parameters = []
        if type == "fedora":
            parameters = fedoraParameters
        elif type == "xtf":
            parameters = xtfParameters
        else:
            exitWithMessage("Type for the workspace %s must be either fedora or xtf!" % section)

        for p in parameters:
            if not config.has_option(section, p):
                exitWithMessage("Please specify %s for the workspace %s!" % (p, section))
            map[p] = config.get(section, p)
    
        # append the configuration mapping to the list
        list.append(map)
    # end of section iteration

    if len(list) == 0:
        exitWithMessage("Please specify at least one workspace in connector.conf!")

    return list
# end of readConfig()


def installConnectors(list):
    if os.path.exists(catalinaHome + "/webapps/connector"):
        shutil.rmtree(catalinaHome + "/webapps/connector")
    shutil.copytree("connector", catalinaHome + "/webapps/connector")

    # create the repository directory
    print "Installing Jackrabbit repository ..."
    if os.path.exists(catalinaHome + "/bin/jackrabbit"):
        # copy the bootstrap.properties only
        shutil.copy("jackrabbit/bootstrap.properties", catalinaHome + "/bin/jackrabbit")
    else:
        shutil.copytree("jackrabbit", catalinaHome + "/bin/jackrabbit")

    # create the workspaces
    print "Creating workspace for connectors ..."
    for workspace in list:
        if os.path.exists(catalinaHome + "/bin/jackrabbit/workspaces/" + workspace["name"]):
            remove = raw_input("Remove existing workspace %s? [y/n]" % workspace["name"])
            if remove == "y":
                shutil.rmtree(catalinaHome + "/bin/jackrabbit/workspaces/" + workspace["name"])
            else:
                continue
        os.mkdir(catalinaHome + "/bin/jackrabbit/workspaces/" + workspace["name"])
        f = open(workspace["type"] + "/workspace.xml", "r")
        workspaceXML = f.read()
        f.close()
        if workspace["type"] == "fedora":
            for p in fedoraParameters:
                workspaceXML = re.sub('"' + p + '" value="[^"]+"', '"' + p + '" value="' + workspace[p] + '"', \
                                          workspaceXML)
        else:
            for p in xtfParameters:
                workspaceXML = re.sub('"' + p + '" value="[^"]+"', '"' + p + '" value="' + workspace[p] + '"', \
                                          workspaceXML)
            workspaceXML = workspaceXML.replace("localhost:8080", catalinaHost + ":" + str(catalinaPort))
            
        workspaceXML = workspaceXML.replace('<Workspace name="' + workspace["type"] + '">', \
                                                '<Workspace name="' + workspace["name"] + '">')
            
        file = open(catalinaHome + "/bin/jackrabbit/workspaces/" + workspace["name"] + "/workspace.xml", "w")
        file.write(workspaceXML)
        file.close()
# end of installConnectors()


if __name__ == "__main__":
    print "This is the installtaion script for the JCR-Connect connect webapp."

    [catalinaHome, catalinaHost, catalinaPort] = configTomcat()

    if not os.path.isfile(configFile):
        shutil.copy(configFileBak, configFile)
    list = readConfig()

    # install the webapps
    print "Installing webapp ..."
    installConnectors(list)

    print "\nInstallation completed!\n"
    print "The repository is available at"
    for workspace in list:
        print "http://" + catalinaHost + ":" + str(catalinaPort) + "/connector/repository/" + workspace["name"]
