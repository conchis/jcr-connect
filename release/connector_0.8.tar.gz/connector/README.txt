-------------------------------------------------------------------
             JCR-Connector Connector Webapp Release 0.8 - December 2010
-------------------------------------------------------------------
This is a release of the JCR connector connector webapp. JCR (Content 
Repository API for Java) is the emerging Java platform API for accessing
content repositories in a uniform manner.

The connector webapp is built on top of JCR repositories and provides easier
access to Fedora and XTF repositories to clients through JCR. It 
translates all node/property storing and loading requests to API calls 
made to the underlying Fedora/XTF repository.

Before using this software, you must read and agree to the the following
license, also found in LICENSE.txt.


License (see also LICENSE.txt)
================================

Copyright 2010 Northwestern University.

Licensed under the Educational Community License, Version 2.0 
(the "License"); you may not use this file except in compliance with 
the License. You may obtain a copy of the License at

http://www.osedu.org/licenses/ECL-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an "AS IS"
BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied. See the License for the specific language governing
permissions and limitations under the License.


Prerequisites
================================
The JCR-Connector connector webapp requires the following software:

- Apache Tomcat 6.0.x
- Python 2.4+

Note that a Jackrabbit 2.1.0 repository will be created during the installation.
The connector webapp can work with or without an existing Jackrabbit
webapp.


Installing JCR-Connect connector webapp
================================

If this is your first time to run the installation script, copy the
template configuration file to a configuration file by executing

cp connector.conf.bak connector.conf

in the connector directory.

Edit connector.conf based on the number and type of repositories
you want to connect using the connector webapp. In this configuration
file each section represents a workspace that connects to either
a Fedora or an XTF repository. 

After configuration is completed, execute

./install.py

which will prompt for the base folder of the Tomcat installation
($CATALINA_HOME), and the host and port that Tomcat is running
on.

The installation script will then create a workspace for each section
of the configuration file in the default Jackrabitt repository under
the bin directory of the Tomcat installation ($CATALINA_HOME/bin).

If both Tomcat and Jackrabbit repository are present, the installation
script will make necessary configuration of Tomcat and Jackrabbit in
order for the connector webapp to function properly.


Test
================================

After installation is completed, start Tomcat. This can be done with the 
startup.bat or startup.sh command in the bin directory of the Tomcat
installation ($CATALINA_HOME/bin). The JCR-Connect connector webapp
will be available at

http://catalina_host:catalina_port/connector

where catalina_host and catalina_port are what have been configured
during the installation. For example, if the Tomcat is for local access
only and running on the default port 8080, and in the configuration
file "connector.conf" a section called "XTF" is configured to connect 
to an existing XTF repository, the following request

http://localhost:8080/connector/repository/xtf

will show the WebDAV interface of the "xtf" workspace which is the
JCR view of the underlying XTF repository.
