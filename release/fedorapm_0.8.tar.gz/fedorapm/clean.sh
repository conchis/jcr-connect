rm -rf jackrabbit/repository/datastore
rm -rf jackrabbit/repository/index
rm -rf jackrabbit/repository/nodetypes
rm -rf jackrabbit/version
rm -rf jackrabbit/workspaces/default/locks
rm -rf jackrabbit/workspaces/default/db
rm -rf jackrabbit/workspaces/default/index
rm -rf jackrabbit/workspaces/security
