#!/usr/bin/python

import shutil

from configTomcat import *


if __name__ == "__main__":
    print "This is the installtaion script for the JCR-Connect category_marker webapp."

    [catalinaHome, catalinaHost, catalinaPort] = configTomcat()

    # install the webapps
    print "installing webapp ..."

    warFile = "category_marker.war"
    shutil.copy(warFile, catalinaHome + "/webapps")

    # update Jackrabbit configuration
    print "updating Jackrabbit configuration ..."
    jackrabbitHome = catalinaHome + "/bin/jackrabbit"
    while (True): 
        if os.path.exists(jackrabbitHome):
            break

        print "Cannot find Jackrabbit repository at " + jackrabbitHome
        jackrabbitHome = raw_input("Please specify the path to Jackrabbit repsository: ")
    # end of iteration
    shutil.copy("bootstrap.properties", jackrabbitHome)

    print "\nInstallation completed!\n"
    print "The search service is available at"
    print "http://" + catalinaHost + ":" + str(catalinaPort) + \
        "/category_marker/service/search?ws=workspacename&q=fire&limit=3"
