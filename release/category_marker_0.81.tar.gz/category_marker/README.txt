-------------------------------------------------------------------
             JCR-Connect Web Services Release 0.8 - December 2010
-------------------------------------------------------------------
This is a release of the JCR connector web services. JCR (Content 
Repository API for Java) is the emerging Java platform API for accessing
content repositories in a uniform manner.

The web services are built on top of JCR repositories and provide easier
RESTful access to the repositories to clients through HTTP.  It translates
all search, access, categorizing requests to JCR API calls made to the 
underlying JCR repository.

Before using this software, you must read and agree to the the following
license, also found in LICENSE.txt.


License (see also LICENSE.txt)
================================

Copyright 2010 Northwestern University.

Licensed under the Educational Community License, Version 2.0 
(the "License"); you may not use this file except in compliance with 
the License. You may obtain a copy of the License at

http://www.osedu.org/licenses/ECL-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an "AS IS"
BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied. See the License for the specific language governing
permissions and limitations under the License.


Prerequisites
================================
The JCR-Connect web services requires the following software:

- Apache Tomcat 6.0.x
- Python 2.4+

Before installing the web services, please make sure a Jackrabbit
2.0+ is running on the Tomcat, or the JCR-Connect connector
webapp has been installed on the Tomcat.


Installing JCR-Connect web services
================================

In the category_marker directory, execute

./install.py

which will prompt for the base folder of the Tomcat installation
($CATALINA_HOME), and the host and port that Tomcat is running
on.

If the installation script could not find a Jackrabbit repository under
the bin directory of the Tomcat installation ($CATALINA_HOME/bin),
it will further prompt for the repository folder.

If both Tomcat and Jackrabbit repository are present, the installation
script will make necessary configuration of Tomcat and Jackrabbit in
order for the web services to function properly.


Test
================================

After installation is completed, start Tomcat. This can be done with the 
startup.bat or startup.sh command in the bin directory of the Tomcat
installation ($CATALINA_HOME/bin). The JCR-Connect services will
be available at

http://catalina_host:catalina_port/category_marker/services

where catalina_host and catalina_port are what have been configured
during the installation. For example, if the Tomcat is for local access
only and running on the default port 8080, the following request

http://localhost:8080/category_marker/service/search?ws=xtf&q=renaissance

will search the xtf workspace for items containing the keyword
"renaissance" and return the results in JSON format.

If the image tiling service will be used, set the parameter "tilingservice"
to proper URL of the tiling service in the file

webapps/category_marker/WEB-INF/web.xml

Note that Tomcat needs to be restarted in order for this to take effect.
