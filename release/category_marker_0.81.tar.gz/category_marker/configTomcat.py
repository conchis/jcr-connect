#!/usr/bin/python

import os.path
import sys
import shutil

jarFile = "jcr-2.0.jar"

def exitWithMessage(message):
    print message
    exit()

def configTomcat():
    print "*** Be cautious the installation will change the configuration of your Tomcat instance. ***"

    while (True): 
        catalinaHome = raw_input("Please specify the path to Tomcat installtaion: ")
        
        if os.path.exists(catalinaHome):
            break
        
        print "Not a valid path!"
    # end of iteration
    catalinaHome = catalinaHome.rstrip('/')

    catalinaHost = raw_input("Please specify the host Tomcat is running on [localhost]: ")
    if catalinaHost == "":
        catalinaHost = "localhost"

    catalinaPort = 8080
    while (True):
        catalinaPort = raw_input("Please specify the port Tomcat is running on [8080]: ")
        if catalinaPort == "":
            catalinaPort = 8080
        catalinaPort = int(catalinaPort)
        if catalinaPort > 0 and catalinaPort < 65536:
            break

        print "Not a valid port!"
    # end of iteration

    # enable global JNDI access to the Jackrabbit repository
    print "Configuring Tomcat ..."
    # add a new source in server.xml
    f = open(catalinaHome + "/conf/server.xml", "r")
    serverXML = f.read()
    f.close()
    resource='<Resource name="jcr/globalRepository"\n \
          auth="Container"\n \
          type="javax.jcr.Repository"\n \
          factory="org.apache.jackrabbit.core.jndi.BindableRepositoryFactory"\n \
          configFilePath="jackrabbit/repository.xml"\n \
          repHomeDir="jackrabbit"/>\n'
    if serverXML.find("jcr/globalRepository") == -1:
        serverXML = serverXML.replace("</GlobalNamingResources>", resource + "</GlobalNamingResources>")
        file = open(catalinaHome + "/conf/server.xml", "w")
        file.write(serverXML)
        file.close()

    # link the source in context.xml
    f = open(catalinaHome + "/conf/context.xml", "r")
    contextXML = f.read()
    f.close()
    resourceLink = '<ResourceLink name="jcr/repository"\n \
              global="jcr/globalRepository"\n \
              type="javax.jcr.Repository"/>\n'
    if contextXML.find("jcr/globalRepository") == -1:
        contextXML = contextXML.replace("</Context>", resourceLink + "</Context>")
        file = open(catalinaHome + "/conf/context.xml", "w")
        file.write(contextXML)
        file.close()        

    # copy jcr jar file
    # note the webapps should not package this jar file under WEB-INF/lib otherwise a ClassCastException will occur
    shutil.copy(jarFile, catalinaHome + "/lib")

    return [catalinaHome, catalinaHost, catalinaPort]
# end of configTomcat
