rm -rf jackrabbit/repository
rm -rf jackrabbit/version
rm -rf jackrabbit/workspaces/default/db
rm -rf jackrabbit/workspaces/default/locks
rm -rf jackrabbit/workspaces/security
rm -f derby.log
