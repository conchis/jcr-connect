/*
 * Copyright 2009 Northwestern University
 *
 * Licensed under the Educational Community License, Version 2.0 
 * (the "License"); you may not use this file except in compliance with 
 * the License. You may obtain a copy of the License at
 * 
 * http://www.osedu.org/licenses/ECL-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS"
 * BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
package edu.northwestern.jcr.adapter.xtf.persistence;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Iterator;

import java.net.URLEncoder;

import javax.jcr.RepositoryException;

import static org.apache.commons.httpclient.HttpStatus.SC_OK;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.PostMethod;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.jdom.input.SAXBuilder;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Namespace;

import edu.northwestern.jcr.adapter.xtf.util.ApplyXPath;

/**
 * <p><code>XTFClient</code> accesses XTF repository
 * through the XTF search servlet.<p> Its key function is to
 * take a raw XML query generated in the query processor
 * and execute agaist the raw servlet, and then return
 * a list of matching documents.
 *
 * @author Xin Xiang
 */
public class XTFClient {

    /** log4j logger. */
    private static Logger log = 
        LoggerFactory.getLogger(XTFClient.class);

    /** URL to the XTF search servlet */  
    private String baseURL;

    /** host of the XTF app */
    private String host = "content.cdlib.org";

    /** port of the XTF app */
    private  String port = "8088";

    /** XTF URL Service */
    private String xtfURLService = "";

    /** Seconds to wait before a connection is established. */
    public int TIMEOUT_SECONDS = 20;

    /** Seconds to wait while waiting for data over the socket (SO_TIMEOUT). */
    public int SOCKET_TIMEOUT_SECONDS = 1800; // 30 minutes

    /** Maxiumum http connections per host (for REST calls only). */
    public int MAX_CONNECTIONS_PER_HOST = 15;

    /** Maxiumum total http connections (for REST calls only). */
    public int MAX_TOTAL_CONNECTIONS = 30;

    /** first part of the raw XML query */
    private static String xmlQuery1 = "<query indexPath=\"index\" style=\"NullStyle.xsl\" ";

    /** second part of the raw XML query */
    private static String xmlQuery2 = "</query>";

    /**
     * Creates a new <code>XTFClient</code> instance. If the
     * property file xtf.properties is present, the property values in 
     * that file are used. Otherwise the default values are used.
     */
    public XTFClient(String h, String p, String x) // throws Exception
    {
        host = h;
        port = p;
        xtfURLService = x;
        baseURL = "http://" + host + ":" + port + "/" + "xtf";
    }

    public XTFClient()
    {
    }

    /**
     * Sends an HTTP GET request and returns the GetMethod instance.
     *
     * @param url URL of the resource
     * @return the GetMethod instance
     */
    private GetMethod httpGet(String url) throws Exception
    {
        GetMethod getMethod;
        MultiThreadedHttpConnectionManager m_cManager;

        m_cManager = new MultiThreadedHttpConnectionManager();
        m_cManager.getParams().setDefaultMaxConnectionsPerHost(MAX_CONNECTIONS_PER_HOST);
        m_cManager.getParams().setMaxTotalConnections(MAX_TOTAL_CONNECTIONS);
        m_cManager.getParams().setConnectionTimeout(TIMEOUT_SECONDS * 1000);
        m_cManager.getParams().setSoTimeout(SOCKET_TIMEOUT_SECONDS * 1000);
        HttpClient client = new HttpClient(m_cManager);

        getMethod = new GetMethod(url);
        getMethod.setDoAuthentication(true);
        getMethod.getParams().setParameter("Connection", "Keep-Alive");
    
        try {
            client.executeMethod(getMethod);
        } catch (Exception e) {
            String msg = "error connecting to the XTF server";
            log.error(msg);
            throw new RepositoryException(msg, null);
        }

        if (getMethod.getStatusCode() != SC_OK) {
            log.warn("status code: " + getMethod.getStatusCode());
        }

        return getMethod;
    }

    /**
     * Sends an HTTP POST request and returns the GetMethod instance.
     *
     * @param url URL of the resource
     * @return the PostMethod instance
     */
    private PostMethod httpPost(String url) throws Exception
    {
        PostMethod postMethod;
        MultiThreadedHttpConnectionManager m_cManager;

        m_cManager = new MultiThreadedHttpConnectionManager();
        m_cManager.getParams()
            .setDefaultMaxConnectionsPerHost(MAX_CONNECTIONS_PER_HOST);
        m_cManager.getParams().setMaxTotalConnections(MAX_TOTAL_CONNECTIONS);
        m_cManager.getParams().setConnectionTimeout(TIMEOUT_SECONDS * 1000);
        m_cManager.getParams().setSoTimeout(SOCKET_TIMEOUT_SECONDS * 1000);
        HttpClient client = new HttpClient(m_cManager);

        postMethod = new PostMethod(url);
        postMethod.setDoAuthentication(true);
        postMethod.getParams().setParameter("Connection", "Keep-Alive");
    
        try {
            client.executeMethod(postMethod);
        } catch (Exception e) {
            String msg = "error connecting to the XTF server";
            log.error(msg);
            throw new RepositoryException(msg, null);
        }

        if (postMethod.getStatusCode() != SC_OK) {
            log.warn("status code: " + postMethod.getStatusCode());
        }

        return postMethod;
    }

    /**
     * Sends an HTTP GET request and returns the response body as
     * a string.
     *
     * @param url URL of the resource
     * @return the response body as <code>String</code>
     */
    private String getMethod(String url) throws Exception
    {
        return httpGet(url).getResponseBodyAsString();
    }

    /**
     * Sends an HTTP POST request and returns the response body as
     * a string.
     *
     * @param url URL of the resource
     * @return the response body as <code>String</code>
     */
    private String postMethod(String url) throws Exception
    {
        return httpPost(url).getResponseBodyAsString();
    }

    /**
     * Sends an HTTP GET request and returns the response body as
     * a byte array.
     *
     * @param url URL of the resource
     * @return the response body as byte array
     */
    private byte [] getMethodByte(String url) throws Exception
    {
        return httpGet(url).getResponseBody();
    }

    /**
     * Returns a list of values for a given facet at a given level.
     *
     * @param path list of path strings
     * @return list of facets
     */
    public String [] getFacet(String [] path) throws Exception
    {
        String body;
        ApplyXPath xpathProc;
        String [] s = null;
        String queryString;
        String xpath;
        int i;

        if (path == null) {
            queryString = "browse-all=yes";
            xpath = "/crossQueryResult/facet[@field='facet-date']/";
        }
        else {
            queryString = "f1-date=";
            xpath = "/crossQueryResult/facet[@field='facet-date']/";
        }

        for (i = 0; path != null && i < path.length; ++i) {
            queryString += path[i];
            xpath += "group[@value='" + path[i] + "']/";

            if (i < path.length - 1) {
                queryString += "::";
            }
        }

        queryString += "&debugStep=4b";
        xpath += "group/@value";

        log.info(queryString);
        log.info(xpath);

        body = getMethod(baseURL + "search?" + queryString);
        xpathProc = new ApplyXPath();
        try {
            s = xpathProc.evaluateString(body, xpath);
        } catch (Exception e) {
      
        }

        return s;
    }

    /**
     * Returns a list of files under a given facet at a given level.
     *
     * @param path list of path strings
     * @return list of files
     */
    public String [] getFiles(String [] path) throws Exception
    {
        String body;
        ApplyXPath xpathProc;
        String [] s = null;
        String queryString;
        String xpath;
        int i;

        queryString = "f1-date=";
        xpath = "/crossQueryResult/docHit/meta[facet-date/text()='";

        for (i = 0; i < path.length; ++i) {
            queryString += path[i];
            xpath += path[i];

            if (i < path.length - 1) {
                queryString += "::";
                xpath += "::";
            }
        }

        queryString += "&debugStep=4b";
        xpath += "']/title/text()";

        // xpath = "/crossQueryResult/docHit/meta[facet-date/text()='2002::01::01']/title/text()";

        System.out.println(queryString);
        System.out.println(xpath);

        body = getMethod(baseURL + "search?" + queryString);
        xpathProc = new ApplyXPath();
        try {
            s = xpathProc.evaluateString(body, xpath);
        } catch (Exception e) {
      
        }

        return s;
    }

    /**
     * Returns the content of file given its title, assuming no two documents
     * have the same title.
     *
     * @param path list of path strings
     * @param title title of the item
     * @return byte content of the file
     */
    public byte [] getFileContent(String [] path, String title) throws Exception
    {
        String body;
        ApplyXPath xpathProc;
        String [] s = null;
        String queryString;
        String xpath;
        String url;
        int i;

        queryString = "f1-date=";
        xpath = "/crossQueryResult/docHit[meta/facet-date/text()='";

        for (i = 0; i < path.length; ++i) {
            queryString += path[i];
            xpath += path[i];

            if (i < path.length - 1) {
                queryString += "::";
                xpath += "::";
            }
        }

        queryString += "&debugStep=4b";
        xpath += "' and meta/title/text() = '" + title + "']/@path";

        System.out.println(queryString);
        System.out.println(xpath);

        body = getMethod(baseURL + "search?" + queryString);
        // System.out.println(body);
        xpathProc = new ApplyXPath();
        try {
            s = xpathProc.evaluateString(body, xpath);
        } catch (Exception e) {
      
        }

        url = baseURL + "data/" + s[0].replaceAll("default:", "");
        // return s[0];
        return getMethodByte(url);
    }

    /**
     * Returns a list of paths for hits of raw XML search.
     *
     * @param query the raw XML query 
     * @param offset the maximum size of the result set
     * @param limit the start offset of the result set
     * @return list of XTFDoc object
     */
    public XTFDoc [] getPath(String query, long offset, long limit) throws Exception
    {
        String body;
        List<String> list;
        String queryString;
        int a, t;
        String path = "";
        String recordNum = "";
        int pageNumber = 1;
        int totalDocs = 0;
        int retrievedDocs = 0;
        String name, value, cValue;
        int count;
        List<XTFDoc> docList;
        XTFDoc doc;
        String identifier, type;
        Document document;
        SAXBuilder parser = new SAXBuilder();

        list = new ArrayList<String>();
        docList = new ArrayList<XTFDoc>();

        // construct the query string
        if (limit < 0) {
            query = "maxDocs=\"all\">" + query;
        }
        else {
            query = "maxDocs=\"" + limit + "\">" + query;
        }
        if (offset > 0) {
            // startDoc defaults to 1
            query = "startDoc=\"" + (offset + 1) + "\" " + query;
        }
        queryString = "query=" + URLEncoder.encode(xmlQuery1 + query + xmlQuery2, "UTF-8");
        log.info("XML Query: " + xmlQuery1 + query + xmlQuery2);

        body = postMethod(baseURL + "/rawQuery?" + queryString);

        document = parser.build(new StringReader(body));
        Element element = document.getRootElement();

        // move the cursor manually
        if (! element.getName().equals("crossQueryResult")) {
            return null;
        }

        totalDocs = Integer.parseInt(element.getAttributeValue("totalDocs"));
        log.info("number of documents: " + totalDocs);

        // navigate to the docHit elements
        List<Element> hitList = element.getChildren("docHit");

        // iterate over all the hits
        for (Element hit : hitList) {
            path = hit.getAttributeValue("path");
      
            // for query result processing
            path = path.replaceAll(":", "/");

            // The "path" attribute of the <docHit> element in the XTF query 
            // results will be used as the JCR path for the corresponding JCR 
            // node in the Jackrabbit repository. The "recordNum" attribute 
            // will also be attached if it is present.
            recordNum = hit.getAttributeValue("recordNum");
            if (recordNum != null) {
                // path and record number
                list.add(path + "/" + recordNum);
            }
            else {
                // no record number, path only
                list.add(path);
            }

            doc = new XTFDoc(path, recordNum);

            element = hit.getChild("meta");

            List<Element> mdList = element.getChildren();

            // iterate over the metadata fields
            identifier = "";
            type = "";

            for (Element md : mdList) {
                name = md.getName();

                if (name.equals("mods")) {
                    // ignore MODS elements
                    continue;
                }

                value = md.getValue();
        
                if (name.equals("identifier") &&
                    value.startsWith("http://")) {
                    identifier = value;
                }
                else if (name.equals("facet-type-tab")) {
                    log.debug("type: " + value);
                    type = value;
                }

                doc.addProperty(name, value);
            } // end of iteration over metadata fields

            if (! identifier.equals("")) {
                setFileURL(doc, identifier, type);
            }
        
            docList.add(doc);

            log.info(++retrievedDocs + " doc(s) retrieved");
        } // iteration of docs

        return docList.toArray(new XTFDoc[0]);
    }

    /**
     * Sets the file URL property values based on the METS document.
     * The file URL can be used for retrieval of the content of the item.
     *
     * @param doc XTFDoc object
     * @param identifier the identifier element in query result
     */
    private void setFileURL(XTFDoc doc, String identifier, String type) 
        throws Exception
    {
        String body = "";
        String metsURL;
        SAXBuilder parser = new SAXBuilder();
        Document document;
        int a;
        String location;

        log.debug("identifier: " + identifier);

        if (type.equals("website") || identifier.indexOf("ark:") < 0) {
            // identifier is the file location
            log.debug("adding: " + identifier);
            doc.addProperty("fileLocation", identifier);

            return;
        }

        // identifier is the METS file location
        metsURL = "http://" + host + "/mets/" +
            identifier.substring(identifier.indexOf("ark:")) + "/";
        log.info("URL of the METS file: " + metsURL);

        if (! xtfURLService.equals("")) {
            if (metsURL.startsWith("http://")) {
                metsURL = metsURL.substring("http://".length());
            }
            doc.addProperty("fileLocation", xtfURLService + "/1/" + metsURL);
            doc.addProperty("fileLocation", xtfURLService + "/2/" + metsURL);

            return;
        }

        try {
            body = getMethod(metsURL);
        } catch (Exception e) {
            log.error("error retrieving the METS file");
        }

        doc.addProperty("mets", body);

        document = parser.build(new StringReader(body));
        Namespace namespace = Namespace.getNamespace("http://www.loc.gov/METS/");
        Element element = document.getRootElement();

        element = element.getChild("fileSec", namespace).getChild("fileGrp", namespace);

        List children = element.getChildren();
        Iterator iterator = children.iterator();
        while (iterator.hasNext()) {
            Element child = (Element) iterator.next();
            if (child.getName().equals("file")) {
                location = child.getChild("FLocat", namespace).getAttributeValue("href",
                                                                                 Namespace.getNamespace("http://www.w3.org/TR/xlink"));
                if (location != null && location.startsWith("http")) {
                    log.debug("adding: " + location);
                    doc.addProperty("fileLocation", location);
                }
            } // if file
        } // file iteration
    }
}
