-------------------------------------------------------------------
             JCR-Connect Image Tiling Service  Release 0.8 - January 2011
-------------------------------------------------------------------
This is a release of the JCR-Connect image tiling service. JCR (Content 
Repository API for Java) is the emerging Java platform API for accessing
content repositories in a uniform manner.

The JCR-Connect image tiling service is a web service written in
Python that takes an image URL and creates tiled version of the
image on the fly. The tiled version of the image is viewable in
the flash-based tiled image viewer.

Before using this software, you must read and agree to the the following
license, also found in LICENSE.txt.


License (see also LICENSE.txt)
================================

Copyright 2010 Northwestern University.

Licensed under the Educational Community License, Version 2.0 
(the "License"); you may not use this file except in compliance with 
the License. You may obtain a copy of the License at

http://www.osedu.org/licenses/ECL-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an "AS IS"
BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
or implied. See the License for the specific language governing
permissions and limitations under the License.


Prerequisites
================================
The JCR-Connector connector webapp requires the following software:

- Python 2.6+


Installing JCR-Connect Image Tiling Service
================================

Installing PIL Library
----------------

The latest version of PIL (Python Imaging Library) is available at

http://www.pythonware.com/products/pil/

Please follow documents in the package to install PIL. Depending
on the kinds of images that are to be tiled, jpeg and png image
libraries will need to be installed before PIL.

Installing CherryPy
----------------

The latest version of CherryPy is available at

http://www.cherrypy.org/

Please follow documents in the package to install CherryPy.

Configuring the Service
--------------------

Edit the configuration file

service.ini

and properly set the parameters

server.socket_host
server.socket_port

to the host and port on which the service is to be running.

Edit the file

image_service/service.py

and set

HOME_DIRECTORY

to the directory where the package is extracted (where the
service.ini file is located).

Test
================================

To test the service, start it by running

python image_service/service.py

and access the URL

http://host:port/upload.wikimedia.org/wikipedia/commons/1/10/Aqueduct_of_Segovia_02.jpg/index.html

where host and port are the parameters set in service.ini.

A tiled image viewer should show a zoomable image in the tiled image viewer
after several seconds' processing.

To run the service in a production environment, execute the script

./start
